# This file makes the services directory a package
from .budget_service import analyze_budget
from .investment_service import suggest_investments
from .data_service import process_data